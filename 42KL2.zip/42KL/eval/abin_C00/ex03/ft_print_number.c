#include <unistd.h>

void ft_putchar(int c)
{
	write (1,&c,1);
}

void ft_print_number(void)
{
	int i;
	i = 48;
	while (i<= 57)
	{
		ft_putchar(i);
		i++;
	}
}

int main()
{
	ft_print_number();
	return 0;
}
