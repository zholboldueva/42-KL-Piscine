/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abin-ahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/08 12:05:37 by abin-ahm          #+#    #+#             */
/*   Updated: 2025/08/08 12:28:27 by abin-ahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_putchar(char c)
{
	write(1, &c, 1);
}

void ft_print_alphabet(void) 
{
	int i;
	i = 97;
	while(i<=122)
	{
		ft_putchar(i);
		i++;
	}
}
int main() 
{
	ft_print_alphabet();
	return 0;
}

