/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 14:09:31 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/12 18:09:06 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_alphabet(void)
{
	int	ascii_a;

	ascii_a = 97;
	while (ascii_a <= 122)
	{
		write (1, &ascii_a, 1);
		ascii_a++;
	}
}

int	main(void)
{
	ft_print_alphabet();
	return (0);
}
