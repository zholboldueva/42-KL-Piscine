/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 18:25:23 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/12 19:15:19 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_reverse_alphabet(void)
{
	int	ascii_z;

	ascii_z = 122;
	while (ascii_z <= 97)
	{
		write (1, &ascii_z, 1);
		ascii_z--;
	}
}

int	main(void)
{
	ft_print_reverse_alphabet();
	return (0);
}
