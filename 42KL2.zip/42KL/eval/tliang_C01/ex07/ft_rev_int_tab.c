/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tliang-q <tliang-q@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 17:43:39 by tliang-q          #+#    #+#             */
/*   Updated: 2025/08/09 18:43:54 by tliang-q         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	offset;
	int	no_of_rounds;
	int	temp;

	offset = 0;
	no_of_rounds = size / 2;
	temp = 0;
	while (no_of_rounds > 0)
	{
		temp = tab[offset];
		tab[offset] = tab[size - 1 - offset];
		tab[size - 1 - offset] = temp;
		no_of_rounds --;
		offset ++;
	}
}
