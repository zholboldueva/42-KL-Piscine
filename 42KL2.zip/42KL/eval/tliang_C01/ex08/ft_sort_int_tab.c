/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tliang-q <tliang-q@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 18:50:22 by tliang-q          #+#    #+#             */
/*   Updated: 2025/08/10 14:17:37 by tliang-q         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int	current;
	int	min_current;
	int	i;
	int	temp;

	current = 0;
	temp = 0;
	while (current < size - 1)
	{
		min_current = current;
		i = min_current + 1;
		while (i < size)
		{
			if (tab[i] < tab[min_current])
				min_current = i;
			i++;
		}
		if (tab[current] != tab[min_current])
		{
			temp = tab[min_current];
			tab[min_current] = tab[current];
			tab[current] = temp;
		}
		current++;
	}
}
