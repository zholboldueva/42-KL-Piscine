/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tliang-q <tliang-q@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/08 11:58:47 by tliang-q          #+#    #+#             */
/*   Updated: 2025/08/11 21:36:57 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
void	ft_ultimate_div_mod(int *a, int *b)
{
	int	init_a;

	init_a = *a;
	*a = init_a / *b;
	*b = init_a % *b;
}
#include <stdio.h>
int main (void){
 
	int v1=10;
	int v=3
	ft_ultimate_div_mod(&v1,&v2);
	printf("%d\n%d\n", v1,v2);

}
