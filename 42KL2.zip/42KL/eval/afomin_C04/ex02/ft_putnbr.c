/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afomin <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 13:41:08 by afomin            #+#    #+#             */
/*   Updated: 2025/08/14 17:34:36 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb)
{
	long	div;
	char	digit;
	char	nl;

	if (nb < 0)
	{
		nl = '-';
		write(1, &nl, 1);
		nb *= -1;
	}
	div = 1;
	while (div < nb)
		div *= 10;
	div /= 10;
	while (div != 0)
	{
		digit = nb / div + 48;
		write(1, &digit, 1);
		nb %= div;
		div /= 10;
	}
	nl = '\n';
	write(1, &nl, 1);
}

int	main(void)
{
	int	a = 2147483647;
	int	b = 533;
	int	c = 142356;
	int	d = -213;

	ft_putnbr(a);
	ft_putnbr(b);
	ft_putnbr(c);
	ft_putnbr(d);
}

