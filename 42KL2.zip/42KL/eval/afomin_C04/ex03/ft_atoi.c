/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afomin <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 14:08:51 by afomin            #+#    #+#             */
/*   Updated: 2025/08/14 17:39:00 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	is_num(char c)
{
	if (c >= '0' && c <= '9')
		return (1);
	return (0);
}

int	getlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	ft_start(int *i, char *str, int *minus)
{
	while (str[*i] == ' ')
		*i = *i + 1;
	while (str[*i] < '0' || str[*i] > '9')
	{
		if (str[*i] == '-')
			*minus = *minus + 1;
		else if (str[*i] != '+')
			return (-1);
		*i = *i + 1;
	}
	return (1);
}

int	ft_atoi(char *str)
{
	int	result;
	int	i;
	int	mult;
	int	minus;

	result = 0;
	i = 0;
	mult = 1;
	minus = 0;
	if (ft_start(&i, str, &minus))
	{
		while (i < getlen(str) && is_num(str[i]))
			i++;
		while (is_num(str[i - 1]))
		{
			result += mult * (int)(str[i - 1] - 48);
			i--;
			mult *= 10;
		}
		if (minus % 2 == 1)
			result = -result;
	}
	return (result);
}

int	main(void)
{
	char	array1[] = "   ----+-12314-23";
	char	array2[] = " ---+-+1234ab567";

	printf("%d\n", ft_atoi(array1));
	printf("%d", ft_atoi(array2));
}

