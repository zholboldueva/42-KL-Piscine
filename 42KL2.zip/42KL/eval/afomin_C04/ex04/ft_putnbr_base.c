/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afomin <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 15:09:53 by afomin            #+#    #+#             */
/*   Updated: 2025/08/14 17:40:34 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	str_len(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	base_valid(char *base)
{
	int	i;
	int	j;
	int	size;

	size = str_len(base);
	i = 0;
	if (size <= 1)
		return (0);
	while (i < size)
	{
		j = 0;
		if (base[i] == '+' || base[i] == '-')
			return (0);
		i++;
		while (j < size)
		{
			j++;
			if (j - 1 == i)
				continue ;
			if (base[i] == base[j - 1])
				return (0);
		}
	}
	return (1);
}

void	print_arr(char *str)
{
	int		i;
	char	ln;

	i = str_len(str) - 1;
	ln = '\n';
	while (i >= 0)
	{
		if (str[i] != ' ')
		{
			write(1, &str[i], 1);
			str[i] = ' ';
		}
		i--;
	}
	write(1, &ln, 1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	char	result[50];
	char	sign;
	int		div;
	int		a;
	int		i;

	if (base_valid(base) != 0)
	{
		if (nbr < 0)
		{
			nbr *= -1;
			sign = '-';
			write(1, &sign, 1);
		}
		i = 0;
		div = str_len(base);
		while (nbr != 0)
		{
			a = nbr % div;
			nbr /= div;
			result[i] = base[a];
			i++;
		}
		print_arr(result);
	}
}

int	main(void)
{
	char	base2[] = "01";
	char	base8[] = "poneyvif";
	char	base10[] = "0123456789";
	char	base16[] = "0123456789ABCDEF";
	char	empty_base[10] = {'\0'};

	ft_putnbr_base(-213, base10);
	ft_putnbr_base(19, base16);
	ft_putnbr_base(-9, base2);
	ft_putnbr_base(21, base8);
	ft_putnbr_base(3, base2);
	ft_putnbr_base(1, empty_base);
	return (0);
}

