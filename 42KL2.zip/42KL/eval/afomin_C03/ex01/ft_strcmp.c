/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afomin <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:10:30 by afomin            #+#    #+#             */
/*   Updated: 2025/08/10 13:26:26 by afomin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
//#include <stdio.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	int	i;

	i = 0;
	while (i < n)
	{
		if (s1[i] > s2[i])
			return (1);
		else if (s1[i] < s2[i])
			return (-1);
		else if (s1[i] == '\0' || s2[i] == '\0')
			return (0);
		i++;
	}
	return (0);
}
/*
int	main(void)
{
	char	str1[3];
	char	str2[2];

	str1[0] = 'C';
	str1[1] = 'a';
	str1[2] = 't';
	str2[0] = 'A';
	str2[1] = 't';
	printf("%d\n", ft_strncmp(str1, str2, 2));
	printf("%d\n", ft_strncmp(str2, str2, 2));
	printf("%d", ft_strncmp(str2, str1, 2));
	return (0);
}
*/
