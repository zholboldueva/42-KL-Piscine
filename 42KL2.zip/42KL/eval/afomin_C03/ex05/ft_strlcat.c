/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afomin <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 17:02:28 by afomin            #+#    #+#             */
/*   Updated: 2025/08/12 18:14:06 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

unsigned int	ft_strlen(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	d;
	unsigned int	s;
	unsigned int	sum;

	i = 0;
	d = ft_strlen(dest);
	s = ft_strlen(src);
	sum = s + d;
	while (src[i] && size > (d + 1))
	{
		dest[d] = src[i];
		d++;
		i++;
	}
	dest[d] = '\0';
	return (sum);
}
 
int	main(void)
{
	char	dest[10] = "Empty st";
	char	src[10] = "ring";
	//10 - 8 - 1 -> +1 char
	printf("----------------\nBefore: %s\n", dest);
	printf("Return: %d\n", ft_strlcat(dest, src, 10));
	printf("After: %s\n", dest);
}

