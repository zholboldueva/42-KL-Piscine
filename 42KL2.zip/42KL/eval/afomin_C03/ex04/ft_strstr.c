/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afomin <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 13:27:21 by afomin            #+#    #+#             */
/*   Updated: 2025/08/12 18:12:16 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
int	getlen(char *line)
{
	int	len;

	len = 0;
	while (line[len] != '\0')
	{
		len++;
	}
	return (len);
}

char	*ft_strstr(char *str, char *to_find)
{
	int		i;
	int		step;

	i = 0;
	step = 0;
	while (str[i] != '\0')
	{
		if (step == getlen(to_find))
			return (str);
		else if (str[i] == to_find[step])
			step++;
		else
			step = 0;
		i++;
	}
	if (step == getlen(to_find))
		return (str);
	return (NULL);
}

int	main(void)
{
	char	str[] = "This is new line";
	char	str4[] = "This is not so new line";
	char	str2[] = "line";
	char	str3[] = "ABOBA";

	printf("%p\n", ft_strstr(str, str2));
	printf("%p\n", ft_strstr(str4, str3));
	printf("%p", strstr(str, str2));
}

