/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 20:09:04 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/24 20:09:22 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
int	is_space(char c)
{
	return (c == ' ' || c == '\t' || c == '\n'
		|| c == '\v' || c == '\f' || c == '\r');
}

int	ft_strlen(char *s)
{
	int i = 0;
	while (s[i])
		i++;
	return (i);
}

int	base_has_char(char *base, char c, int upto)
{
	int i = 0;

	while (i < upto)
	{
		if (base[i] == c)
			return (1);
		i++;
	}
	return (0);
}

int	is_base_valid(char *base)
{
	int i;
	int len;

	len = ft_strlen(base);
	if (len < 2)
		return (0);
	i = 0;
	while (base[i])
	{
		/* no '+' or '-' or any whitespace in base */
		if (base[i] == '+' || base[i] == '-' || is_space(base[i]))
			return (0);
		/* no duplicates */
		if (base_has_char(base, base[i], i))
			return (0);
		i++;
	}
	return (1);
}

int	index_in_base(char c, char *base)
{
	int i = 0;

	while (base[i])
	{
		if (base[i] == c)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi_base(char *str, char *base)
{
	int		sign;
	long	result;
	int		blen;
	int		idx;

	if (!is_base_valid(base))
		return (0);
	blen = ft_strlen(base);
	/* skip leading whitespace */
	while (*str && is_space(*str))
		str++;
	/* handle multiple leading signs */
	sign = 1;
	while (*str == '+' || *str == '-')
	{
		if (*str == '-')
			sign = -sign;
		str++;
	}
	/* parse digits */
	result = 0;
	while (*str)
	{
		idx = index_in_base(*str, base);
		if (idx < 0)
			break ;
		result = result * blen + idx;
		str++;
	}
	return ((int)(sign * result));
}
