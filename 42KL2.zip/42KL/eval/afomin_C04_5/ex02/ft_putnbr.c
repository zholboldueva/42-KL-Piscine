/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afomin <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 13:41:08 by afomin            #+#    #+#             */
/*   Updated: 2025/08/17 22:19:33 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char ch)
{
	write(1, &ch, 1);
}

void	ft_putnbr(int nb)
{
	long	div;
	long	num;
	char	digit;

	if (nb == 0)
		ft_putchar(nb + 48);
	num = nb;
	if (num < 0l)
	{
		ft_putchar('-');
		num *= -1;
	}
	div = 1;
	while (div < num)
		div *= 10;
	div /= 10;
	while (div != 0)
	{
		digit = num / div + 48;
		write(1, &digit, 1);
		num %= div;
		div /= 10;
	}
}

int	main(void)
{
	int	a = 2147483647;
	int	b = -2147483648;
	int	c = 142356;
	int	d = -213;

	ft_putnbr(a);
	ft_putnbr(b);
	ft_putnbr(c);
	ft_putnbr(d);
}

