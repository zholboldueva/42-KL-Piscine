/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: afomin <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 15:09:53 by afomin            #+#    #+#             */
/*   Updated: 2025/08/14 15:14:45 by afomin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_is_base_valid(char *base)
{
	int	i;
	int	j;
	int	len;

	len = ft_strlen (base);
	if (len < 2)
		return (0);
	i = 0;
	while (base[i])
	{
		if (base[i] == '+' || base[i] == '-'
			|| base[i] < 32 || base[i] > 126)
			return (0);
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

void	put_in_base_unsigned(unsigned long n, char *base, int blen)
{
	if (n >= (unsigned long)blen)
		put_in_base_unsigned(n / blen, base, blen);
	ft_putchar(base[n % blen]);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int				blen;
	long			tmp;

	if (!ft_is_base_valid(base))
		return ;
	blen = ft_strlen(base);
	tmp = (long)nbr;
	if (tmp < 0)
	{
		ft_putchar('-');
		tmp = -tmp;
	}
	if (tmp == 0)
	{
		ft_putchar(base[0]);
		return ;
	}
	put_in_base_unsigned((unsigned long)tmp, base, blen);
}
/*
int	main(void)
{
	char	base2[] = "01";
	char	base8[] = "poneyvif";
	char	base10[] = "0123456789";
	char	base16[] = "0123456789ABCDEF";

	ft_putnbr_base(-2147483648, base10);
	ft_putnbr_base(2147483647, base16);
	ft_putnbr_base(-9, base2);
	ft_putnbr_base(21, base8);
	ft_putnbr_base(3, base2);
	return (0);
}*/
