#!/bin/bash
ifconfig | awk '{if($1=="ether"){print $2}}'|while read mac; do printf "%s\n" "$mac"; done
