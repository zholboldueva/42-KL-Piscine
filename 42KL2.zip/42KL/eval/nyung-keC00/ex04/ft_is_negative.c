#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>


void ft_is_negative(int n){
	
	if(n < 0){

	printf("N\n");

	} else {

	printf("P\n");

	}

}
	

int main(){

	ft_is_negative(-2);
	ft_is_negative(2);
	return 0;

}

