#include <unistd.h>
#include <stdio.h>


void ft_print_numbers(void){

	for(char i = '0'; i <= '9' ; i++){
	printf("%c", i);

	}
}

int main(){
	
	ft_print_numbers();
	return 0;

}

