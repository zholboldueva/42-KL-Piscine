#!/bin/sh
git log | grep ^commit | cut -c 8- | head -n 5
