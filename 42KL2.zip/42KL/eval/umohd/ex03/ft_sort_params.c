/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: umohd-as <umohd-as@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/28 11:16:08 by umohd-as          #+#    #+#             */
/*   Updated: 2025/08/28 12:40:50 by umohd-as         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
int	ft_strcmp(char *str1, char *str2)
{
	int	i;

	i = 0;
	while (str1[i] && str1[i] == str2[i])
	{
		i++;
	}
	return (str1[i] - str2[i]);
}
// when you want to swap two elements of argv, you need to swap the pointers, not the characters inside the string.
// argv is an array of pointers, each element argv[i] is a char *str.
// if you want to swap the strings in the argument list, you're actually swapping the char *pointers
// 
void	ft_swap(char **a, char **b)
{
	char  *temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void ft_putstr(char *str){
	int i;
	i = 0;
	while(str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}
int	main(int argc, char *argv[])
{
	int	i;

	i = 1;
	while (i < argc - 1)
	{
		if (ft_strcmp(argv[i], argv[i + 1]) > 0)
		{
			ft_swap(&argv[i], &argv[i+1]);
			i = 0;
		}
		i++;
	}
	i = 1;
	while (i < argc)
	{
		ft_putstr(argv[i]);
		i++;
	}
}
