/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: umohd-as <umohd-as@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 22:13:47 by umohd-as          #+#    #+#             */
/*   Updated: 2025/08/27 22:30:44 by umohd-as         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write (1, &str[i], 1);
		i++;
	}
}

int	main(int argc, char *argv[])
{
	int	i;

	if (argc == 1)
		return (0);
	else
	{
		i = argc - 1;
		while (i > 0)
		{
			ft_putstr(argv[i]);
			write (1, "\n", 1);
			i--;
		}
	}
	return (0);
}
