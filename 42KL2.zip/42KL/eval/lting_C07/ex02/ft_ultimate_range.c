/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lting <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 22:32:53 by lting             #+#    #+#             */
/*   Updated: 2025/08/24 23:12:34 by lting            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

void	alloc(int **range, int min, int max)
{
	int	index;
	int	value;
	int	size;

	size = max - min;
	*range = (int *)malloc(sizeof(int) * (size));
	if (*range == NULL)
		return ;
	index = 0;
	value = min;
	while (value < max)
	{
		(*range)[index] = value;
		index++;
		value++;
	}
}

int	ft_ultimate_range(int **range, int min, int max)
{
	if (min > max)
	{
		*range = NULL;
		return (-1);
	}
	alloc(range, min, max);
	if (*range == NULL)
		return (0);
	return (max - min);
}

#include <stdio.h>
int	main(void)
{
	int	*array;
	int	min = 0;
	int	max = 10;

	printf("%d\n", ft_ultimate_range(&array, min, max));
	for (int i = 0; i < max - min; i++)
	{
		printf("%d ", array[i]);
	}
	return (0);
}
