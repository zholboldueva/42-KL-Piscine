/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lting <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 23:08:22 by lting             #+#    #+#             */
/*   Updated: 2025/08/25 19:02:43 by lting            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdlib.h>

char	*ft_strcat(char *dest, const char *src)
{
	int	i;
	int	j;

	if (!dest || !src)
		return (dest);
	i = 0;
	while (dest[i])
		i++;
	j = 0;
	while (src[j])
	{
		dest[i] = src[j];
		i++;
		j++;
	}
	dest[i] = '\0';
	return (dest);
}

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len])
	{
		len++;
	}
	return (len);
}

int	ft_strslen(int size, char **strs, char *sep)
{
	int	i;
	int	total;

	i = 0;
	total = 0;
	while (i < size && strs[i])
	{
		total += ft_strlen(strs[i]);
		if (i < size - 1 && strs[i + 1])
			total += ft_strlen(sep);
		i++;
	}
	return (total);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*result;
	int		i;

	if (size == 0)
	{
		result = (char *)malloc(sizeof(char) * 1);
		if (result == NULL)
			return (NULL);
		result[0] = '\0';
		return (result);
	}
	result = (char *)malloc(sizeof(char) * (ft_strslen(size, strs, sep) + 1));
	if (result == NULL)
		return (NULL);
	result[0] = '\0';
	i = 0;
	while (i < size)
	{
		ft_strcat(result, strs[i]);
		if (i < size - 1)
			ft_strcat(result, sep);
		i++;
	}
	return (result);
}

#include <stdio.h>
#include <string.h>
int    main(void)
{
    char    *test1[] = {"Hello", "world", "!", NULL};
    char    *test2[] = {"Hello", NULL};
    char    *test3[] = {"", "Hello", "", "world", "", NULL};
    char    *test4[] = {"", "", "", NULL};
    char    *test5[] = {"A", "B", "C", NULL};
    char    *test6[] = {"2023", "10", "15", NULL};
    char    *test7[] = {"Ignore", "these", NULL};
    char    *test8[] = {"A", "B", NULL, "C"};
    //char    **test9 = NULL;
    //char    *test10[] = {"A", "B", NULL};
    char    *test11[] = {"A", "B", NULL};
    char    *res11;

    printf("%s\n", ft_strjoin(3, test1, " "));
    printf("%s\n", ft_strjoin(1, test2, "---"));
    printf("%s\n", ft_strjoin(5, test3, "-"));
    printf("%s\n", ft_strjoin(3, test4, "X"));
    printf("%s\n", ft_strjoin(3, test5, ""));
    printf("%s\n", ft_strjoin(3, test6, "/"));
    printf("%s\n", ft_strjoin(0, test7, ""));
    printf("%s\n", ft_strjoin(4, test8, "-"));
    //printf("%s\n", ft_strjoin(3, test9, ","));
    //printf("%s\n", ft_strjoin(2, test10, NULL));
    res11 = ft_strjoin(0, test11, " ");
    printf("Should be the same: %d\n", strcmp(res11, ""));
    free(res11);
    return (0);
}
