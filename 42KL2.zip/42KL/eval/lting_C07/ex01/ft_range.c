/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lting <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 21:24:10 by lting             #+#    #+#             */
/*   Updated: 2025/08/24 22:32:15 by lting            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdlib.h>

int	*alloc(int min, int max)
{
	int	index;
	int	value;
	int	*temp;

	temp = (int *)malloc(sizeof(int) * (max - min));
	if (temp == NULL)
		return (NULL);
	index = 0;
	value = min;
	while (value < max)
	{
		temp[index] = value;
		index++;
		value++;
	}
	return (temp);
}

int	*ft_range(int min, int max)
{
	if (min > max)
		return (NULL);
	return (alloc(min, max));
}

int	main(void)
{
	int	*ptr;
	int	min = 0;
	int	max = 10;

	ptr = ft_range(min, max);
	if (ptr == NULL)
	{
		printf("error\n");
		return (1);
	}
	for (int i = 0; i < max - min; i++)
	{
		printf("%d ", ptr[i]);
	}
	free(ptr);
	return (0);
}
