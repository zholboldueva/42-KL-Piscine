/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aalkhede <aalkhede@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/07 11:53:42 by aalkhede          #+#    #+#             */
/*   Updated: 2025/08/09 08:50:47 by aalkhede         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

/*int	main(void)
{
	ft_putcihar('d');
	return (0);
}*/

void	ft_putchar(char c)
{
	write(1, &c, 1);
}
