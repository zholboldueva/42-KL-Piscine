/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saprioty <saprioty@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/13 19:35:35 by saprioty          #+#    #+#             */
/*   Updated: 2025/08/14 17:06:19 by saprioty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		if (!(str[i] >= 0 && str[i] <= 31))
		{
			return (1);
		}
		i++;
	}
	return (0);
}
/*int     main()
{
        char alphabet[] = "abc";
        
        int     is_printable = ft_str_is_printable(alphabet);

        if (is_printable == 1)
        {
                printf("This string only contains PRINTABLE CHARACTERS\n");
        }
        else
        {
                printf("Contains NON-PRINTABLE CHARACTERS\n");
        }
        return (0);
}*/
