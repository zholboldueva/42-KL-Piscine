/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saprioty <saprioty@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 17:53:52 by saprioty          #+#    #+#             */
/*   Updated: 2025/08/13 14:25:02 by saprioty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}
/*
int main()
{
	char source[12] = "Hello World";
	char destination[12];

	printf("\nBefore using ft_strcpy\n");
	printf("Source: %s\n", source); 
	printf("Destination: %s\n", destination);
	printf("\n---------\n");

	ft_strcpy(destination, source);
	
	printf("After using ft_strcpy\n");
	printf("Source: %s\n", source); 
	printf("Destination: %s\n", destination);
}*/
