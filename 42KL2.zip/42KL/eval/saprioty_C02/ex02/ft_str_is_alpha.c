/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saprioty <saprioty@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 11:37:29 by saprioty          #+#    #+#             */
/*   Updated: 2025/08/14 16:51:12 by saprioty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
		{
			return (0);
		}
		else if (!(str[i] >= 'A' && str[i] <= 'Z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
int	main()
{
	char alphabet[] = "abc";
	
	int	is_alpha = ft_str_is_alpha(alphabet);

	if (is_alpha == 1)
	{
		printf("This string only contains ALPHABETS\n");
	}
	else
	{
		printf("Contains characters OTHER than the ALPHABETS\n");
	}
	return (0);
}*/
