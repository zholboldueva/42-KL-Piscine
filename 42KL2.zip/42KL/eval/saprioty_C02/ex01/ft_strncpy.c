/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saprioty <saprioty@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 18:35:17 by saprioty          #+#    #+#             */
/*   Updated: 2025/08/14 18:05:35 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (src[i] != 0 && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

int	main(void)
{
	char	n[20];
	char	*d;
	unsigned int	size = 2;

	d = "Hello";
	//ft_strncpy(n, d, size);
	char *result = ft_strncpy(n, d,size);
	
	printf("dest: %s\n", result);
	//printf("source: %s\n", d);
	//printf("unassigned size: %d\n", size);

	return (0);
}
