/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saprioty <saprioty@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/13 19:03:06 by saprioty          #+#    #+#             */
/*   Updated: 2025/08/14 12:45:34 by saprioty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
int     main()
{
        char alphabet[] = "abc";
        
        int     is_capital = ft_str_is_uppercase(alphabet);

        if (is_capital == 1)
        {
                printf("This string only contains Uppercase ALPHABETS\n");
        }
        else
        {
                printf("Contains characters OTHER than Uppercase ALPHABETS\n");
        }
        return (0);
}*/
