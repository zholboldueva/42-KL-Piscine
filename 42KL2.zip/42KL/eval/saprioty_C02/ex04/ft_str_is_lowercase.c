/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saprioty <saprioty@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/13 18:19:49 by saprioty          #+#    #+#             */
/*   Updated: 2025/08/13 20:58:29 by saprioty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
int     main()
{
        char alphabet[] = "abc";

        int     is_lower = ft_str_is_lowercase(alphabet);

        if (is_lower == 1)
        {
                printf("This string only contains LOWERCASE ALPHABETS\n");
        }
        else
        {
                printf("Contains Other Characters\n");
        }
        return (0);
}*/
