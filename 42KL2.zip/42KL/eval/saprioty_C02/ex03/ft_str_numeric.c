/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_numeric.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saprioty <saprioty@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 13:33:59 by saprioty          #+#    #+#             */
/*   Updated: 2025/08/14 17:03:45 by saprioty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= '0' && str[i] <= '9'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
int	main()
{
	char str[] = "123a";

	int	is_numeric = ft_str_is_numeric(str);

	ft_str_is_numeric(str);



	if (is_numeric == 1)
	{
		printf ("Contains only numerics");
	}
	else
	{
		printf ("Contains other characters");
	}
	return 0;

}*/
