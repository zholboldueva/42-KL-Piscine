/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aghulam- <aghulam-@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/23 13:55:06 by aghulam-          #+#    #+#             */
/*   Updated: 2025/08/23 15:51:22 by aghulam-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	result;
	int	i;

	result = 1;
	i = 0;
	while (i < power)
	{
		result *= nb;
		i++;
	}
	return (result);
}

#include <stdio.h>

int	main(void)
{
	int	x;
	int	pow;

	x = 2;
	pow = 3;
	printf("%d", ft_iterative_power(x, pow));
	return (0);
}
