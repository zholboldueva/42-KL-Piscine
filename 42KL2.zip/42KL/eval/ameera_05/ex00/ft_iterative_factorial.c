/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aghulam- <aghulam-@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/22 20:54:52 by aghulam-          #+#    #+#             */
/*   Updated: 2025/08/28 09:54:27 by aghulam-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	i;
	int	facto;

	i = 1;
	facto = 1;
	if (nb < 0)
	{
		return (0);
	}
	if (nb == 0)
	{
		return (1);
	}
	while (i <= nb)
	{
		facto = facto * i;
		i++;
	}
	return (facto);
}
#include <stdio.h>

int	main(void)
{
	int	num;

	num = 12;
	printf("%d", ft_iterative_factorial(num));
	return (0);
}
