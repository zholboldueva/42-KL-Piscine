/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amamyrov <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/19 13:08:36 by amamyrov          #+#    #+#             */
/*   Updated: 2025/08/19 20:13:57 by amamyrov         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

static void	print_two(int n)
{
	char	d1;
	char	d2;

	d1 = '0' + (n / 10);
	d2 = '0' + (n % 10);
	write(1, &d1, 1);
	write(1, &d2, 1);
}

void	ft_print_comb2(void)
{
	int		a;
	int		b;

	a = 0;
	while (a <= 98)
	{
		b = a + 1;
		while (b <= 99)
		{
			print_two(a);
			write(1, " ", 1);
			print_two(b);
			if (!(a == 98 && b == 99))
				write(1, ", ", 2);
			b++;
		}
		a++;
	}
}
/*int main()
{
	ft_print_comb2();
	return (0);
}*/
