/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amamyrov <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/19 17:43:43 by amamyrov          #+#    #+#             */
/*   Updated: 2025/08/19 18:26:09 by amamyrov         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_combn(int n)
{
	char	arr[10];
	int		i;

	i = 0;
	while (i < n)
	{
		arr[i] = '0' + i;
		i++;
	}
	while (1)
	{
		write(1, arr, n);
		if (arr[0] == '0' + (10 - n) && arr[n - 1] == '9')
			break ;
		write(1, ", ", 2);
		i = n - 1;
		while (i >= 0 && arr[i] == '9' - (n - 1 - i))
			i--;
		arr[i]++;
		while (++i < n)
			arr[i] = arr[i - 1] + 1;
	}
}
/*int main()
{
	ft_print_combn(3);
	return (0);
}*/
