/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbin-bak <hbin-bak@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/14 17:10:31 by hbin-bak          #+#    #+#             */
/*   Updated: 2025/08/14 17:42:20 by hbin-bak         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

int	ft_str_is_uppercase(char *str);

int	ft_str_is_uppercase(char *str)
{
	if (*str == '\0')
		return (1);
	while (*str != '\0')
	{
		if ((*str >= 'A' && *str <= 'Z'))
		{
			str++;
		}
		else
			return (0);
	}
	return (1);
}
int main(){
	char a[] = "abcdef";
	char b[] = "ACBC";
	char c[] = "";
	char d[] = "!@#$^";

	int z = ft_str_is_uppercase(a);
	int e = ft_str_is_uppercase(b);
	int f = ft_str_is_uppercase(c);
	int y = ft_str_is_uppercase(d);

	printf("%d\n", z);
	printf("%d\n", e);
	printf("%d\n", f);
	printf("%d\n", y);
}
