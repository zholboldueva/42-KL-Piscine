/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbin-bak <hbin-bak@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 20:58:03 by hbin-bak          #+#    #+#             */
/*   Updated: 2025/08/14 20:35:56 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n);

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	char			*org_dest;
	unsigned int	i;

	org_dest = dest;
	i = 0;
	while (i < n && src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	return (org_dest);
}
#include <string.h>
int	main(){
	char source[] = "Hello World!";
    	char copy[] = "mydin maju jaya";

    	
	printf("%s\n", ft_strncpy(copy, source, 5));
    	printf("%s\n", strncpy(copy,source,5));
}
