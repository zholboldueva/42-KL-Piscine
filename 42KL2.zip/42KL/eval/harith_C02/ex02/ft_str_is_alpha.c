/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hbin-bak <hbin-bak@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/14 17:04:09 by hbin-bak          #+#    #+#             */
/*   Updated: 2025/08/14 17:27:55 by hbin-bak         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

int	ft_str_is_alpha(char *str);

int	ft_str_is_alpha(char *str)
{
	if (*str == '\0')
		return (1);
	while (*str != '\0')
	{
		if ((*str >= 'A' && *str <= 'Z') || (*str >= 'a' && *str <= 'z'))
		{
			str++;
		}
		else
			return (0);
	}
	return (1);
} 
int main(){
 	char a[] = "abcABC";
 	char b[] = "abc1abc";
 	char c[] = "";

 	int d = ft_str_is_alpha(a);
 	int e = ft_str_is_alpha(b);
 	int f = ft_str_is_alpha(c);
 	printf("%d\n", d);
 	printf("%d\n", e);
 	printf("%d\n", f);
 }
