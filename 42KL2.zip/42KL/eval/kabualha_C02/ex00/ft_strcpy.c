/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/21 19:45:42 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/24 23:00:23 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char *src)
{
	int	text_length;

	text_length = 0;
	while (src[text_length] != '\0')
	{
		dest[text_length] = src[text_length];
		text_length++;
	}
	dest[text_length] = '\0';
	return (dest);
}
/*
#include <stdio.h>
int main (void)
{
	char	src[] = "khalil";
	char	dest[3];
	ft_strcpy(dest, src);
	printf("%s", dest);
	return (0);
}
*/
