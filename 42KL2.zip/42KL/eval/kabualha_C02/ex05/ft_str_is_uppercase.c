/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 18:06:13 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/25 14:55:01 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
#include <stdio.h>
int main(void)
{
	printf("%d\n", ft_str_is_uppercase("HAKLSHA"));
	printf("%d\n", ft_str_is_uppercase("HAgggggKLSHA"));
	printf("%d\n", ft_str_is_uppercase("fdsfdsfsd"));
	printf("%d\n", ft_str_is_uppercase("123@!#"));
	printf("%d\n", ft_str_is_uppercase(""));
}
*/
