/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 16:54:36 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/24 18:05:08 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
#include <stdio.h>
int main(void)
{
	printf("%d\n", ft_str_is_lowercase("HAKLSHA"));
	printf("%d\n", ft_str_is_lowercase("HAgggggKLSHA"));
	printf("%d\n", ft_str_is_lowercase("fdsfdsfsd"));
	printf("%d\n", ft_str_is_lowercase("123@!#"));
	printf("%d\n", ft_str_is_lowercase(""));
}
*/
