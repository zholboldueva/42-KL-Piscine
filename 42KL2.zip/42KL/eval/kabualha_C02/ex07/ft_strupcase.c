/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 18:21:07 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/25 15:10:47 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] <= 'Z' && str[i] >= 'A')
		{
			i++;
		}
		else if (str[i] <= 'z' && str[i] >= 'a')
		{
			str[i] -= 32;
			i++;
		}
		else
		{
			i++;
		}
	}
	return (str);
}


#include <stdio.h>
int	main(void)
{
	char	str[] = "hgkdNYFREfdhhgf3232";

	char	*store = ft_strupcase(str);

	printf("%s", store);
	return (0);
}

