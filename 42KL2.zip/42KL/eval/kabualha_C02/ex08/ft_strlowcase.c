/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 18:28:43 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/25 15:12:41 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] <= 'Z' && str[i] >= 'A')
		{
			str[i] += 32;
			i++;
		}
		else if (str[i] <= 'z' && str[i] >= 'a')
		{
			i++;
		}
		else
		{
			i++;
		}
	}
	return (str);
}


#include <stdio.h>
int	main(void)
{
	char	str[] = "hgkdNYFREfdhhg3223";

	char	*store = ft_strlowcase(str);

	printf("%s", store);
	return (0);
}

