/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 16:10:31 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/25 18:17:04 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!((str[i] >= 'A' && str[i] <= 'Z')
				|| (str[i] >= 'a' && str[i] <= 'z')))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
#include <stdio.h>
int main(void)
{
	printf("%d\n", ft_str_is_alpha("HAKLSHA"));
	printf("%d\n", ft_str_is_alpha("HAgggggKLSHA"));
	printf("%d\n", ft_str_is_alpha("HAKL1234432SHA"));
	printf("%d\n", ft_str_is_alpha("123@!#"));
	printf("%d\n", ft_str_is_alpha(""));
}
*/
