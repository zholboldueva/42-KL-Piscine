/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/21 20:48:34 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/25 18:20:51 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	sample;

	sample = 0;
	while (sample < n && src[sample] != '\0')
	{
		dest[sample] = src[sample];
		sample++;
	}
	while (sample < n)
	{
		dest[sample] = '\0';
	}
	return (dest);
}
/* 
#include <stdio.h>
int main (void)
{
	char src[] = "smooth criminal";
	char dest[199];
	int n = 4;

	ft_strncpy(dest, src, n);
	printf("%s", dest);
	return (0);
}
 */
