/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 16:47:02 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/24 18:36:59 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= '0' && str[i] <= '9'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
#include <stdio.h>
int main(void)
{
	printf("%d\n", ft_str_is_numeric("1231241243"));
	printf("%d\n", ft_str_is_numeric("Hfew34342sdf35fdsf"));
	printf("%d\n", ft_str_is_numeric("123@!#"));
	printf("%d\n", ft_str_is_numeric(""));
}
*/
