/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kabualha <kabualha@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 18:10:14 by kabualha          #+#    #+#             */
/*   Updated: 2025/08/24 18:35:46 by kabualha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] < 126 && str[i] > 32))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*
#include <stdio.h>
int main(void)
{
	printf("%d\n", ft_str_is_printable("HAKLSHA"));
	printf("%d\n", ft_str_is_printable("HAgggggKLSHA"));
	printf("%d\n", ft_str_is_printable("fdsfdsfsd"));
	printf("%d\n", ft_str_is_printable("123@!#"));
	printf("%d\n", ft_str_is_printable(""));
}
*/
