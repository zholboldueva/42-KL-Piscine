/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aghulam- <aghulam-@student.42kl.edu.m      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 17:09:09 by aghulam-          #+#    #+#             */
/*   Updated: 2025/08/26 10:00:52 by aghulam-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	int	i;
	int	index;

	index = 1;
	while (index < argc)
	{
		i = 0;
		while (argv[index][i] != '\0')
		{
			write (1, &argv[index][i], 1);
			i++;
		}
		write (1, "\n", 1);
		index++;
	}
	return (0);
}
