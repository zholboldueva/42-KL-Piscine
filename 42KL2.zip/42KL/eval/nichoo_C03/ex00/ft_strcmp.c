/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nichoo <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 20:51:34 by nichoo            #+#    #+#             */
/*   Updated: 2025/08/11 19:26:22 by nichoo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] && s2[i])
	{
		if (s1[i] != s2[i])
			break ;
		i++;
	}
	return (s1[i] - s2[i]);
}

/*
int main(int ac, char **av)
{
	if (ac < 2)
		return 0 ;
	
	char *s1 = av[1];
	char *s2 = av[2];
	int result;

	printf("\nstrcmp implementation:-\n");
	printf("Return: %d\n", result = strcmp(s1, s2));
	printf("------\n");
	printf("ft_strcmp implementation:-\n");
	printf("Return: %d\n", result = ft_strcmp(s1, s2));
}
*/
