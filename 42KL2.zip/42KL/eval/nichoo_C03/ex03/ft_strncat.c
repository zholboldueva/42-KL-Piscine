/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nichoo <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 11:18:59 by nichoo            #+#    #+#             */
/*   Updated: 2025/08/12 17:24:41 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

unsigned int	ft_strlen(char *s)
{
	unsigned int	length;

	length = 0;
	while (s[length])
		length++;
	return (length);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	unsigned int	dest_length;

	i = 0;
	dest_length = ft_strlen(dest);
	while (i < nb && src[i])
	{
		dest[dest_length + i] = src[i];
		i++;
	}
	dest[dest_length + i] = 0;
	return (dest);
}


int main()
{
	char source[50], dest[20], dest2[20];
	
	strcpy(source, "This is source");
	strcpy(dest, "This is destination");
	strcpy(dest2, "This is destination");
	
	int size = 20;

	printf("\nstrncat implementation:-\n");
	printf("Before:-\nSource: |%s|\n", source);
	printf("Destination: |%s|\n", dest);
	ft_strncat(dest, source, size);
	printf("After:-\nDestination: |%s|\n", dest);
	printf("\nft_strncat implementation:-\n");
	printf("Before:-\nSource: |%s|\n", source);
	printf("Destination: |%s|\n", dest2);
	strncat(dest2, source, size);
	printf("After:-\nDestination: |%s|\n", dest2);	


	printf("----------\n");
	char source3[] = "Beautiful World!";
	char dest3[20] = "Hello, ";
	
	printf("\nBefore:-\nSource: |%s|\n", source3);
	printf("Destination: |%s|\n", dest3);
	ft_strncat(dest3, source3 + 10, 5);
	printf("After:-\nDestination: |%s|\n", dest3);
}
