/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nichoo <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 11:48:49 by nichoo            #+#    #+#             */
/*   Updated: 2025/08/12 17:29:07 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

int	ft_strlen(char *s)
{
	int	length;

	length = 0;
	while (s[length])
		length++;
	return (length);
}

int	ft_strncmp(char *s1, char *s2, int n)
{
	int	i;

	if (n == 0)
		return (0);
	i = 0;
	while (s1[i] && s2[i] && i < n - 1)
	{
		if (s1[i] != s2[i])
			break ;
		i++;
	}
	return (s1[i] - s2[i]);
}

char	*ft_strstr(char *str, char *to_find)
{
	int	length_to_find;

	length_to_find = ft_strlen(to_find);
	if (*str == 0 && *to_find == 0)
		return (str);
	while (*str)
	{
		if (!ft_strncmp(str, to_find, length_to_find))
			return (str);
		str++;
	}
	return (0);
}


int main(int ac, char **av)
{
	if (ac < 3)
		return 0;

	char *str = av[1];
	char *str2 = av[1];
	char *to_find = av[2];

	printf("\nstrstr implementation:-\n");
	printf("str: |%s|\nto_find: |%s|\n", str, to_find);
	str = strstr(str, to_find);
	printf("Resulting str: |%s|\n", str); 
	printf("\nft_strstr implementation:-\n");
	printf("str2: |%s|\nto_find: |%s|\n", str2, to_find);
	str2 = ft_strstr(str2, to_find);
	printf("Resulting str: |%s|\n", str2); 

}

