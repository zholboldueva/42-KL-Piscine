/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nichoo <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 21:18:47 by nichoo            #+#    #+#             */
/*   Updated: 2025/08/12 17:19:50 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

int	ft_strlen(char *s)
{
	int	length;

	length = 0;
	while (s[length])
		length++;
	return (length);
}

char	*ft_strcat(char *dest, char *src)
{
	int	dest_length;
	int	i;

	i = -1;
	dest_length = ft_strlen(dest);
	while (src[++i])
		dest[dest_length + i] = src[i];
	dest[dest_length + i] = 0;
	return (dest);
}


int main()
{
	char dest[32] = "This is";
	char dest2[32] = "This is";
	char src[50] = " a potentially long string";

	ft_strcat(dest, src);
	strcat(dest2, src);
	printf("\nft_strcat implementation:-\n");
	printf("|%s|\n", dest);
	printf("------\n");
	printf("strcat implementation:-\n");
	printf("|%s|\n", dest2);
}

