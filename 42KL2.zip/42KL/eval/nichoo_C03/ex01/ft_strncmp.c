/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nichoo <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 21:03:30 by nichoo            #+#    #+#             */
/*   Updated: 2025/08/12 17:16:44 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	if (n == 0)
		return (0);
	i = 0;
	while (s1[i] && s2[i] && i < n - 1)
	{
		if (s1[i] != s2[i])
			break ;
		i++;
	}
	return (s1[i] - s2[i]);
}


int main(int ac, char **av)
{
	if (ac < 4)
		return 0;
	char *s1 = av[1];
	char *s2 = av[2];
	unsigned int size = atoi(av[3]);
	int result;

	printf("\nstrncmp implementation:-\n");
	printf("Result: %d\n", result = strncmp(s1, s2, size));
	printf("--------\n");
	printf("ft_strncmp implementation:-\n");
	printf("Result: %d\n", result = ft_strncmp(s1, s2, size));
}

