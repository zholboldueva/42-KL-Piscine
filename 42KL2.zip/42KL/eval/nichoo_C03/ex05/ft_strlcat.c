/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nichoo <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/11 12:33:43 by nichoo            #+#    #+#             */
/*   Updated: 2025/08/12 17:35:54 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

unsigned int	ft_strlen(char *s)
{
	unsigned int	length;

	length = 0;
	while (s[length])
		length++;
	return (length);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	dest_length;
	unsigned int	src_length;
	unsigned int	total_length;

	i = 0;
	dest_length = ft_strlen(dest);
	src_length = ft_strlen(src);
	total_length = dest_length + src_length;
	if (dest_length > size)
		return (total_length - (dest_length - size));
	while (src[i] && dest_length < size - 1)
		dest[dest_length++] = src[i++];
	while (dest_length < size)
		dest[dest_length++] = 0;
	return (total_length);
}


int main()
{
	char src[50], dest[50];
	unsigned int size = 5;
	unsigned int result;

	strcpy(dest, "This is");
	strcpy(src, " a potentially long line");
	
	printf("dest: |%s|\n", dest);
	printf("src: |%s|\n", src);
	result = ft_strlcat(dest, src, size);
	printf("new dest: |%s|\n", dest);
	printf("result: %d\n", result);

}

