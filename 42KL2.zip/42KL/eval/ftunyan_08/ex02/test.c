#include "ft_abs.h"
#include <stdio.h>

int main()
{
	int a = ABS(-10);
	printf("%d", a);
}
