git log --pretty=tformat:%H -n5
