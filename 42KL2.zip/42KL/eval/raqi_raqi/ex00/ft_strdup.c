/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: raqi <raqi@student.42kl.edu.my>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 12:48:00 by raqi              #+#    #+#             */
/*   Updated: 2025/08/28 00:47:02 by raqi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

char	*ft_strdup(char *src)
{
	int	length;
	int	i;
	char	
		*copy;

	length = 0;
	while (src[length] != '\0')
	{
		length++;
	}
	copy = (char *)malloc((length + 1) * sizeof(char));
	if (copy == NULL)
		return (NULL);
	i = 0;
	while (i < length)
	{
		copy[i] = src[i];
		i++;
	}
	copy[i] = '\0';
	return (copy);
}
#include <string.h>
int	main(void)
{
	char *original = "Hello, 42!";
	char *duplicate;

	duplicate = strdup(original);
	if (duplicate == NULL)
	{
		printf("Memory allocation failed!\n");
		return(1);
	}

	//duplicate[0] = 'B';//
	printf("Original String = %s\n", original);
	printf("Updated String = %s\n", duplicate);
	free (duplicate);
	return (0);
}
