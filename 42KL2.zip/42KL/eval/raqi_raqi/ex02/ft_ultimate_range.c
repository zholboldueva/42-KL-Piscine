/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: raqi <raqi@student.42kl.edu.my>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 21:11:01 by raqi              #+#    #+#             */
/*   Updated: 2025/08/28 00:48:36 by raqi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	ft_ultimate_range(int *range[], int min, int max)
{
	int	*arr;
	int	length;
	int	i;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	length = max - min;
	arr = (int *)malloc(length * sizeof(int));
	if (arr == NULL)
		return (-1);
	i = 0;
	while (i < length)
	{
		arr[i] = min + i;
		i++;
	}
	*range = arr;
	return (length);
}

int	main(void)
{
	int	*numbers;
	int	size;
	int	i;

	size = ft_ultimate_range(&numbers, 3, 7);
	if (size == -1)
	{
		printf("Memory allocation failed!\n");
		return (0);
	}
	else if (size == 0)
	{
		printf("Empty range where min >= max\n");
		return (0);
	}
	i = 0;
	while (i < size)
	{
		printf("%d ", numbers[i]);
		i++;
	}
	printf("\n%d\n", size);
	free (numbers);
	return (0);
}
