/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: raqi <raqi@student.42kl.edu.my>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 20:50:05 by raqi              #+#    #+#             */
/*   Updated: 2025/08/28 00:47:55 by raqi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*array;
	int	length;
	int	i;

	if (min >= max)
	{
		return (NULL);
	}
	length = max - min;
	array = (int *)malloc(length * sizeof(int));
	if (array == NULL)
	{
		return (NULL);
	}
	i = 0;
	while (i < length)
	{
		array[i] = min + i;
		i++;
	}
	return (array);
}

int	main(void)
{
	int	min = 3;
	int	max = 9;
	int	*arr;
	int	i;

	arr = ft_range(min, max);
	if (arr == NULL)
	{
		printf("Memory allocation failed!");
		return (1);
	}
	printf(" Array from %d to %d: \n", min, max);
	i = 0;
	while (i < max - min)
	{
		printf("%d ", arr[i]);
		i++;
	}
	printf("\n");
	free(arr);
	return (0);
}
