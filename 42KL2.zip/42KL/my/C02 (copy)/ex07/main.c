/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:55:45 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 13:01:49 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
char *ft_strupcase(char *str);

int main(void){

	char input1[10]="lk";
	char input2[10]="sezi";
	
//	int test1=ft_str_is_alpha(input1);
//	printf("%d\n",test1);
	char *test1 = ft_strupcase(input1);
	char *test2 = ft_strupcase(input2);
	printf("%s\n%s\n",test1,test2);
	

	return 0;


}

