/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 08:16:51 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 08:26:34 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

char	*ft_strncpy(char *dest, char *src,unsigned int n);
char	*ft_strcpy(char *dest,char *src);

int	main(void)
{
	char	src[]= "hello copied world!";
	char	dest1[] = "Hello destinatin string";
	char    dest2[]= "Hello destinatin string";
	ft_strcpy(dest1,src);
	ft_strncpy(dest2, src,sizeof(dest2));
	
	printf("CPY: %s\n", dest1);
	write(1,dest1,sizeof(dest1));
	write(1,"\n",1);
	printf("NCPY: %s\n", dest2);
	write(1,dest2,sizeof(dest2));
	return (0);
}
