/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:55:45 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 13:01:49 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
char *ft_strcapitalize(char *str);

int main(void){

	char input1[50]="hey fde grd hreh 34gfe";
	
//	int test1=ft_str_is_alpha(input1);
//	printf("%d\n",test1);
	char *test1 = ft_strcapitalize(input1);
	
	printf("%s\n",test1);
	

	return 0;


}

