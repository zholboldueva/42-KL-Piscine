/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 08:16:51 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 08:26:34 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

char	*ft_strcpy(char	*dest, char *src);

int	main(void)
{
	char	src[]= "hello copied world!";
	char	dest[] = "Hello destinatin string";
	ft_strcpy(dest, src);
	printf("CPY: %s\n", dest);
	write(1,dest,sizeof(dest));
	return (0);
}
