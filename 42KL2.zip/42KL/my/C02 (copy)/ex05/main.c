/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:55:45 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 13:01:49 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
int ft_str_is_uppercase(char *str);

int main(void){

	char input1[10]="1l2";
	char input2[10]="LK";
	char input3[10]="";
	char input4[10]="fege1,";
	
//	int test1=ft_str_is_alpha(input1);
//	printf("%d\n",test1);
	char test1[2]={'0'+ft_str_is_uppercase(input1),' '};
	write(1,test1,2);
	char test2[2]={'0'+ft_str_is_uppercase(input2),' '};
	write(1,test2,2);
	char test3[2]={'0'+ft_str_is_uppercase(input3),' '};
	write(1,test3,2);
	char test4[2]={'0'+ft_str_is_uppercase(input4),' '};
	write(1,test4,2);

	return 0;


}

