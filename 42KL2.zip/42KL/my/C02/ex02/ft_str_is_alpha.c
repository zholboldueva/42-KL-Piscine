/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:47:50 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 12:55:34 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_is_alpha(char s);

int	ft_str_is_alpha(char *str)
{
	int	result;
	int	i;

	result = 1;
	i = 0;
	while (str[i] != '\0')
	{
		if (!(ft_is_alpha(str[i])))
		{
			result = 0;
			break ;
		}
		i++;
	}
	return (result);
}

int	ft_is_alpha(char s)
{
	if ((s >= 'A' && s <= 'Z')
		|| (s >= 'a' && s <= 'z'))
		return (1);
	return (0);
}
