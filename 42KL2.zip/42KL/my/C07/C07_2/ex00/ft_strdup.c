/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/21 11:18:35 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/21 11:24:57 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <malloc.h>

int	ft_strlen(char *src)
{
	int	len;

	len = 0;
	while (*src++)
		len++;
	return (len);
}

char	*ft_strcpy(char	*dest,	char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

char	*ft_strdup(char *src)
{
	char	*new_str;

	if (src == NULL)
		return (NULL);
	new_str = (char *)malloc(ft_strlen(src) + 1);
	if (new_str == NULL)
		return (NULL);
	ft_strcpy(new_str, src);
	return (new_str);
}
/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    const char *original = "Hello, World!";
    char *duplicate;
    char *test1 = " hello Sezi!";
    char *testdupl;

    duplicate = strdup(original);
    testdupl = ft_strdup(test1);

    if (duplicate == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        return 1;
    }

    if (testdupl == NULL) {
        fprintf(stderr, "My Memory allocation failed.\n");
        return 1;
    }

    printf("Original: %s\n", original);
    printf("Duplicate: %s\n", duplicate);
    
    printf("My Original: %s\n", test1);
    printf("My Duplicate: %s\n", testdupl);

    free(duplicate);
    free(testdupl);
    return 0;
}*/
