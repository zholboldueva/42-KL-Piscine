/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: you <you@student.42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 00:00:00 by you               #+#    #+#             */
/*   Updated: 2025/08/25 00:00:00 by you              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
int	ft_index_in_base(char c, char *base);

int	ft_base_len(char *base)
{
	int	len;

	if (!base)
		return (0);
	len = 0;
	while (base[len])
		len++;
	return (len);
}

int	ft_is_valid_base(char *base)
{
	int	len;
	int	i;
	int	j;

	len = ft_base_len(base);
	if (len < 2)
		return (0);
	i = 0;
	while (i < len)
	{
		if (base[i] == '+' || base[i] == '-' || base[i] == ' '
			|| base[i] == '\t' || base[i] == '\n' || base[i] == '\v'
			|| base[i] == '\f' || base[i] == '\r')
			return (0);
		j = i + 1;
		while (j < len)
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

static char	*skip_ws_and_signs(char *s, int *sign)
{
	*sign = 1;
	while (*s == ' ' || *s == '\t' || *s == '\n'
		|| *s == '\v' || *s == '\f' || *s == '\r')
		s++;
	while (*s == '+' || *s == '-')
	{
		if (*s == '-')
			*sign = -*sign;
		s++;
	}
	return (s);
}

static int	assign_out(int sign, long long mag, int *out)
{
	long long	v;

	if (sign >= 0)
		v = mag;
	else
		v = -mag;
	*out = (int)v;
	if ((long long)*out != v)
		return (0);
	return (1);
}

int	ft_atoi_base_strict(char *str, char *base, int *out)
{
	int			sign;
	int			d;
	long long	mag;

	if (!str || !base || !out || !ft_is_valid_base(base))
		return (0);
	str = skip_ws_and_signs(str, &sign);
	d = ft_index_in_base(*str, base);
	if (d < 0)
		return (0);
	mag = 0;
	while (d >= 0)
	{
		mag = mag * (long long)ft_base_len(base) + (long long)d;
		if (sign >= 0 && (long long)(int)mag != mag)
			return (0);
		if (sign < 0 && (long long)(int)(-mag) != -mag)
			return (0);
		str++;
		d = ft_index_in_base(*str, base);
	}
	return (assign_out(sign, mag, out));
}
