/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: you <you@student.42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 00:00:00 by you               #+#    #+#             */
/*   Updated: 2025/08/25 00:00:00 by you              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_is_valid_base(char *base);
int		ft_base_len(char *base);
int		ft_atoi_base_strict(char *str, char *base, int *out_value);
int		ft_index_in_base(char c, char *base);

static int	ft_udigits_count(unsigned long n, int b)
{
	int	count;

	count = 1;
	while (n >= (unsigned long)b)
	{
		n /= (unsigned long)b;
		count++;
	}
	return (count);
}

static void	ft_fill_digits(char *s, unsigned long u, char *base, int *len)
{
	int	b;

	b = ft_base_len(base);
	if (u == 0)
		s[--(*len)] = base[0];
	while (u > 0)
	{
		s[--(*len)] = base[u % (unsigned long)b];
		u /= (unsigned long)b;
	}
}

static void	ft_set_mag(int n, int *neg, unsigned long *u)
{
	*neg = 0;
	if (n < 0)
	{
		*neg = 1;
		*u = (unsigned long)(-(long)n);
	}
	else
		*u = (unsigned long)n;
}

char	*ft_itoa_base_alloc(int n, char *base)
{
	int				neg;
	unsigned long	u;
	int				len;
	char			*s;

	if (!ft_is_valid_base(base))
		return (NULL);
	ft_set_mag(n, &neg, &u);
	len = ft_udigits_count(u, ft_base_len(base));
	if (neg)
		len++;
	s = (char *)malloc((size_t)len + 1);
	if (!s)
		return (NULL);
	s[len] = '\0';
	ft_fill_digits(s, u, base, &len);
	if (neg)
		s[0] = '-';
	return (s);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	int	value;

	if (!nbr || !base_from || !base_to)
		return (NULL);
	if (!ft_is_valid_base(base_from) || !ft_is_valid_base(base_to))
		return (NULL);
	if (!ft_atoi_base_strict(nbr, base_from, &value))
		return (NULL);
	return (ft_itoa_base_alloc(value, base_to));
}
