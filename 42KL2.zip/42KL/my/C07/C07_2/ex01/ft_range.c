/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/21 11:54:47 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/21 12:06:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <malloc.h>

int	*ft_range(int min, int max)
{
	int	*arr;
	int	i;
	int	size;

	if (min >= max)
		return (NULL);
	size = max - min;
	arr = (int *)malloc(size * sizeof(int));
	if (!arr)
		return (NULL);
	i = 0;
	while (i < size)
	{
		arr[i] = min + i;
		i++;
	}
	return (arr);
}
/*
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    int min = -3;
    int max = 5;
    int *arr = ft_range(min, max);

    if (!arr)
    {
        printf("ft_range returned NULL\n");
        return 1;
    }
    printf("loop     : ");
    for (int i = min; i < max; i++)
        printf("%d ", i);
    printf("\n");
    printf("ft_range : ");
    for (int i = 0; i < (max - min); i++)
        printf("%d ", arr[i]);
    printf("\n");

    free(arr);
    return 0;
} */
