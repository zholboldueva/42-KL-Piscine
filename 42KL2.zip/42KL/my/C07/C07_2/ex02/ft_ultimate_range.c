/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/21 21:45:08 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/24 15:17:28 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <malloc.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	*p;
	int	size;
	int	*arr;

	if (!range)
		return (-1);
	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	size = max - min;
	arr = malloc(size * sizeof(int));
	if (!arr)
	{
		*range = NULL;
		return (-1);
	}
	p = arr;
	while (min < max)
		*p++ = min++;
	*range = arr;
	return (size);
}
/*
#include <stdio.h>
int main(void)
{
	int *arr;
	int size;
	int i;

	printf("address of arr:%p, value of arr:%p\n", &arr, arr);
	size = ft_ultimate_range(&arr, 3, 8);
	printf("Returned size = %d\n", size);

	printf("address of arr:%p, value of arr:%p\n", &arr, arr);
	size = ft_ultimate_range(&arr, 3, 8);
	if (size > 0)
	{
		for (i = 0; i < size; i++)
			printf("%d ", arr[i]);
		printf("\n");
		free(arr);
	}
	else if (size == 0)
	{
		printf("Empty range\n");
	}
	else
	{
		printf("Error (malloc failed)\n");
	}
	return 0;
}
*/
