/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_queens_puzzle.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/18 17:58:56 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/18 18:25:08 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	is_safe(int board[], int col, int row)
{
	int	i;

	i = 0;
	while (i < col)
	{
		if (board[i] == row)
			return (0);
		if ((board[i] - i) == (row - col))
			return (0);
		if ((board[i] + i) == (row + col))
			return (0);
		i++;
	}
	return (1);
}

void	print_board(int board[])
{
	int	i;
	char	c;
	 = 0;
    

    while (i < 10)
    {
        c = board[i] + '0';
        write(1, &c, 1);
        i++;
    }
    write(1, "\n", 1);
}

void solve(int board[], int col, int *count)
{
    int row = 0;

    if (col == 10)
    {
        print_board(board);
        (*count)++;
        return ;
    }
    while (row < 10)
    {
        if (is_safe(board, col, row))
        {
            board[col] = row;
            solve(board, col + 1, count);
        }
        row++;
    }
}

int ft_ten_queens_puzzle(void)
{
    int board[10];
    int count;

    count = 0;
    solve(board, 0, &count);
    return (count);
}

int main(void)
{
    int total;
    total = ft_ten_queens_puzzle();

    if (total >= 10)
        write(1, (char[]){(total / 10) + '0', (total % 10) + '0', '\n'}, 3);
    else
        write(1, (char[]){total + '0', '\n'}, 2);
    return (0);
}

