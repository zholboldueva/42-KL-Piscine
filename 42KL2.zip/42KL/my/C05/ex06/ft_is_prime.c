/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/18 17:58:56 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/18 18:25:08 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_is_prime(int nb)
{
	int	i;
	int	result;

	i = 3;
	result = 1;
	if (nb <= 1)
		result = 0;
	if (nb == 2)
		result = 1;
	if (nb % 2 == 0)
		result = 0;
	while (i * i <= nb)
	{
		if (nb % i == 0)
			result = 0;
		i += 2;
	}
	return (result);
}

#include <stdio.h>
int main(void)
{
printf("%d\n",ft_is_prime(79));
return (0);
}
