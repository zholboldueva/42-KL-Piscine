/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 12:35:47 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/09 13:04:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_strncmp(char	*s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && (*s1 || *s2))
	{
		if (*s1 != *s2)
			return ((int)(unsigned) *s1 - (int)(unsigned) *s2);
		s1++;
		s2++;
		i++;
	}
	return (0);
}
/* 
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int	main(void)
{

	char input1[4]="heyf";
	char input2[15]="heygtwrgwt";
	

	int test1 = ft_strncmp(input1, input2, 4);
	int test2 = strncmp(input1,input2,4);
	printf("%d\n",test1);
	printf("%d\n",test2);
	return (0);
} */
