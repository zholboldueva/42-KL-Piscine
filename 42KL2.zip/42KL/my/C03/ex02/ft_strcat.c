/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 12:35:47 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/09 13:04:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

char	*ft_strcat(char	*dest, char *src)
{
	char	*d;

	d = dest;
	while (*d)
		d++;
	while (*src)
		*d++ = *src++;
	*d = '\0';
	return (dest);
}
/*
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int	main(void)
{

	char input1[4]="hef";
	char input2[4]="hey";
	char input3[4]="hef";
	char input4[4]="hey";
	
	printf("%s\n",ft_strcat(input1, input2));
	printf("%s\n",strcat(input3,input4));
	return (0);
} */
