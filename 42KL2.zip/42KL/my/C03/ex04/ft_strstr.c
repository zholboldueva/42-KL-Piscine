/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 12:35:47 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/09 13:04:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

char	*ft_strstr(char *str, char *to_find)
{
	char	*s;
	char	*t;

	if (!*to_find)
		return (str);
	while (*str)
	{
		s = str;
		t = to_find;
		while (*s && *t && (*s == *t))
		{
			s++;
			t++;
		}
		if (!*t)
			return (str);
		str++;
	}
	return (NULL);
}
/* #include <stdlib.h>
#include <stdio.h>
#include <string.h>

int	main(void)
{

	char input1[4]="hef";
	char input2[10]="heyhef";
	char input3[4]="hef";
	char input4[10]="heyhef";
	
	printf("%s\n",ft_strstr(input2, input1));
	printf("%s\n",strstr(input4,input3));
	return (0);
}*/
