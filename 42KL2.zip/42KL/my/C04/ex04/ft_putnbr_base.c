/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/12 20:35:47 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/13 12:04:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len] != '\0')
		len++;
	return (len);
}

int	ft_for_base(int i, char *base, int len)
{
	while (i < len)
	{
		if (base[i] == '+' || base[i] == '-')
			return (0);
		else if (base[i] == ' ' || (base[i] >= 9 && base[i] <= 13))
			return (0);
		i++;
	}
	return (i);
}

int	is_base_valid(char *base)
{
	int	len;
	int	i;
	int	j;

	len = ft_strlen(base);
	if (len <= 1)
		return (0);
	i = 0;
	ft_for_base(i, base, len);
	i = 0;
	while (i < len)
	{
		j = i + 1;
		while (j < len)
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	long	current_nbr;
	long	base_length;

	if (!is_base_valid(base))
		return ;
	base_length = ft_strlen(base);
	current_nbr = nbr;
	if (current_nbr < 0)
	{
		ft_putchar('-');
		current_nbr = -current_nbr;
	}
	if (current_nbr >= base_length)
		ft_putnbr_base(current_nbr / base_length, base);
	ft_putchar(base[current_nbr % base_length]);
}
/*
#include <stdio.h>
#include <stdlib.h> // For INT_MIN, INT_MAX in main

int main( int argc, char **argv)
{
	int	 n;
	if (argc != 3)
	{
	printf("Usage: %s <number> <base_string>\n", argv[0]);
        printf("Example: %s 42 \"0123456789\"\n", argv[0]);
        printf("Example: %s -10 \"01\"\n", argv[0]);
        printf("Example: %s 255 \"0123456789ABCDEF\"\n", argv[0]);
        return (1); // Indicate an error by returning 1
	}
	
	n = atoi(argv[1]);
	printf("Input: Number = %s, Base = \"%s\"\n", argv[1], argv[2]);
	
	ft_putnbr_base(n, argv[2]);
	
	


    return 0;
}*/
