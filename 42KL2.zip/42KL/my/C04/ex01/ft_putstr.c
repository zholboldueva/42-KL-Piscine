/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 12:35:47 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/09 13:04:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putstr(char	*str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}
/*
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
void	ft_putstr(char *str);

int	main(void)
{
	char test[5] = "hello";
	
	printf("%s\n",test);
	ft_putstr(test);
	return (0);
} */
