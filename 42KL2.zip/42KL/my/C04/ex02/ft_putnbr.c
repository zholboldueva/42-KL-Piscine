/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 12:35:47 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/09 13:04:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void ft_putnbr( int nb)
{
	long nbl;
	char c;

	nbl = nb;
	if( nbl < 0)
	{
		nbl = -nbl;
		write(1, "-",1);
	}
	if(nbl >= 10)
		ft_putnbr(nbl/10);
	c = (nbl/10)+'0';
	write (1, &c, c);
	
		
/*
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int	main(void)
{


	
	ft_putnbr(-3665);
	return (0);
} */
