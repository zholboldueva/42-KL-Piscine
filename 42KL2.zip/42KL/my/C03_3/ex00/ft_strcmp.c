/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/09 12:35:47 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/09 13:04:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_strcmp(char	*s1, char *s2)
{
	while (*s1 && (*s1 == *s2))
	{
		s1++;
		s2++;
	}
	return (*s1 - *s2);
}
  #include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int	main(void)
{

	char input1[4]="hey";
	char input2[4]="hiy";
	

	int test1 = ft_strcmp(input1, input2);
	int test2 = strcmp(input1, input2);
	printf("%d\n",test1);
	printf("%d\n",test2);
	return (0);
}
