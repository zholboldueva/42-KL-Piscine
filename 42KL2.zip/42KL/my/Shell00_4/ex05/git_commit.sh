git rev-list HEAD -n 5
