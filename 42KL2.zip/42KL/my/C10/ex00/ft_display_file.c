/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display-file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 10:25:09 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/27 10:26:58 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <fcntl.h>

#define BUFFER_SIZE 1024

static void	print_error(char *msg)
{
	while (*msg)
	{
		write(2, msg, 1);
		msg++;
	}
}

static int	check_args(int argc)
{
	if (argc < 2)
	{
		print_error("File name missing.\n");
		return (0);
	}
	if (argc > 2)
	{
		print_error("Too many arguments.\n");
		return (0);
	}
	return (1);
}

static int	display_file(char *filename)
{
	int		fd;
	int		n;
	char	buf[BUFFER_SIZE];

	fd = open(filename, O_RDONLY);
	if (fd < 0)
	{
		print_error("Cannot read file.\n");
		return (1);
	}
	n = (int)read(fd, buf, BUFFER_SIZE);
	while (n > 0)
	{
		write(1, buf, (unsigned int)n);
		n = (int)read(fd, buf, BUFFER_SIZE);
	}
	if (n < 0)
		print_error("Cannot read file.\n");
	close(fd);
	return (0);
}

int	main(int argc, char **argv)
{
	if (!check_args(argc))
		return (1);
	return (display_file(argv[1]));
}
