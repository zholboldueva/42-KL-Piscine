/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cat.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 11:20:45 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/27 11:21:09 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <libgen.h>

#define BUFFER_SIZE 30000

static void	print_str(int fd, const char *s)
{
	while (*s)
	{
		if (write(fd, s, 1) < 0)
			return ;
		s++;
	}
}

static void	print_error(const char *prog, const char *path)
{
	char	*base;

	base = basename((char *)prog);
	print_str(2, base);
	print_str(2, ": ");
	print_str(2, path);
	print_str(2, ": ");
	print_str(2, (char *)strerror(errno));
	print_str(2, "\n");
}

static int	display_fd(int fd)
{
	int		n;
	int		off;
	int		w;
	char	buf[BUFFER_SIZE];

	n = (int)read(fd, buf, BUFFER_SIZE);
	while (n > 0)
	{
		off = 0;
		while (off < n)
		{
			w = (int)write(1, buf + off, (unsigned int)(n - off));
			if (w < 0)
				return (-1);
			off += w;
		}
		n = (int)read(fd, buf, BUFFER_SIZE);
	}
	if (n < 0)
		return (-1);
	return (0);
}

static int	handle_one(const char *prog, const char *arg)
{
	int	fd;
	int	ret;

	fd = -1;
	if (arg[0] == '-' && arg[1] == '\0')
		fd = 0;
	else
		fd = open(arg, O_RDONLY);
	if (fd < 0)
	{
		print_error(prog, arg);
		return (1);
	}
	ret = display_fd(fd);
	if (ret < 0)
		print_error(prog, arg);
	if (fd != 0)
		close(fd);
	if (ret < 0)
		return (1);
	return (0);
}

int	main(int argc, char **argv)
{
	int	i;
	int	status;

	if (argc == 1)
	{
		if (display_fd(0) < 0)
			return (1);
		return (0);
	}
	status = 0;
	i = 1;
	while (i < argc)
	{
		if (handle_one(argv[0], argv[i]) != 0)
			status = 1;
		i++;
	}
	return (status);
}
