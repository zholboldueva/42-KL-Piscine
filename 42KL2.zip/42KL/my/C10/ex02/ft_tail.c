/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tail.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 11:52:43 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/27 11:54:37 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <fcntl.h>
#include <unistd.h>

int	ft_atoi(char *str)
{
	int	i;
	int	sum;

	i = 0;
	sum = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		++i;
	while (str[i] == '-' || str[i] == '+')
		i++;
	while (str[i] >= '0' && str[i] <= '9')
	{
		sum = sum * 10 + str[i] - '0';
		i++;
	}
	return (sum);
}

int	ft_file_size(char *file_name)
{
	int		size;
	int		file;
	char	buffer;

	file = open(file_name, O_RDONLY);
	size = 0;
	if (file < 0)
	{
		write(2, "ft_tail: ", 9);
		while (*file_name)
			write(2, file_name++, 1);
		write(2, ": No such  file or directory\n", 28);
		return (-1);
	}
	else
		while (read(file, &buffer, 1) > 0)
			++size;
	close(file);
	return (size);
}

void	ft_display( char *file_name, int size, int bytes)
{
	char	buffer;
	int		file;
	int		n;

	n = 0;
	file = open(file_name, O_RDONLY);
	while (read(file, &buffer, 1) > 0)
	{
		if (++n >= size - bytes +1)
			write(1, &buffer, 1);
	}
	close(file);
}

void	ft_print_header(int i, char *file_name)
{
	if (i == 3)
		write(1, "==>", 4);
	else
		write(1, "\n==>", 5);
	while (*file_name)
		write(1, file_name++, 1);
	write(1, " <==\n", 5);
}

int	main(int argc, char **argv)
{
	int	i;
	int	size;
	int	bytes;

	i = 3;
	if (argv[1][0] == '-' && argv[1][1] == 'c' && argc >= 4)
	{
		bytes = ft_atoi(argv[2]);
		while (i < argc)
		{
			if (argc > 4)
				ft_print_header(i, argv[i]);
			size = ft_file_size(argv[i]);
			ft_display(argv[i], size, bytes);
			i++;
		}
	}
	else
		write(1, "Use: ./ft_tail -c N file1 file2 ...\n", 37);
	return (0);
}
