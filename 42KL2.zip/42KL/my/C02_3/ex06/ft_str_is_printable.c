/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:47:50 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 12:55:34 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_str_is_printable(char *str)
{
	unsigned char	c;

	if (!str)
		return (0);
	while (*str)
	{
		c = (unsigned char)*str;
		if (c < 32 || c > 126)
			return (0);
		str++;
	}
	return (1);
}
