/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/18 17:58:56 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/18 18:25:08 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_sqrt(int nb)
{
	int	i;
	int	result;

	i = 2;
	result = 0;
	if (nb < 0)
		result = 0;
	if (nb == 0 || nb == 1)
		result = nb;
	while (i <= nb)
	{
		if (nb == i * i)
			result = i;
		i++;
	}
	return (result);
}
/*
#include <stdio.h>
int main(void)
{
printf("%d\n",ft_sqrt(8));
return (0);
} */
