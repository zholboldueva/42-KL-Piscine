/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/18 17:58:56 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/18 18:25:08 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_fibonacci(int index)
{
	int	n1;
	int	n2;
	int	nxt;
	int	count;

	n1 = 0;
	n2 = 1;
	count = 0;
	if (index < 0)
		return (-1);
	while (count < index)
	{
		nxt = n1 + n2;
		n1 = n2;
		n2 = nxt;
		count++;
	}
	return (n1);
}
/*
#include <stdio.h>
int main(void)
{
printf("%d\n",ft_fibonacci(12));
return (0);
} */
