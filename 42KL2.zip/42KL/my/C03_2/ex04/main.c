/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:55:45 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 13:01:49 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
char	*ft_strstr(char *str, char *to_find);

int	main(void)
{

	char input1[4]="hef";
	char input2[10]="heyhef";
	char input3[4]="hef";
	char input4[10]="heyhef";
	
	printf("%s\n",ft_strstr(input2, input1));
	printf("%s\n",strstr(input4,input3));
	return (0);
}

