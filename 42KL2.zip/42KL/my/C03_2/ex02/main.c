/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:55:45 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 13:01:49 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
char	*ft_strcat(char *dest, char *src);

int	main(void)
{

	char input1[4]="hef";
	char input2[4]="hey";
	char input3[4]="hef";
	char input4[4]="hey";
	
	printf("%s\n",ft_strcat(input1, input2));
	printf("%s\n",strcat(input3,input4));
	return (0);
}

