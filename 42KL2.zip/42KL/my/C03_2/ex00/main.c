/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:55:45 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 13:01:49 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
char	ft_strcmp(char *s1, char *s2);

int	main(void)
{

	char input1[4]="hey";
	char input2[4]="hey";
	

	int test1 = ft_strcmp(input1, input2);
	int test2 = strcmp(input1, input2);
	printf("%d\n",test1);
	printf("%d\n",test2);
	return (0);
}

