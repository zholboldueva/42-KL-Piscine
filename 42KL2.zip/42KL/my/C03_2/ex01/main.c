/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: szholbol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/10 12:55:45 by szholbol          #+#    #+#             */
/*   Updated: 2025/08/10 13:01:49 by szholbol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
char	ft_strncmp(char *s1, char *s2, unsigned int n);

int	main(void)
{

	char input1[4]="hey";
	char input2[4]="heyf";
	

	int test1 = ft_strncmp(input1, input2,3);
	int test2 = strncmp(input1,input2,3);
	printf("%d\n",test1);
	printf("%d\n",test2);
	return (0);
}

